import React, { useState, useEffect, useMemo } from 'react';
import { 
  Rocket, Coins, Zap, ShoppingCart, Users, Timer, Moon, Sun, 
  TrendingUp, DollarSign, Flame, PieChart as ChartPie, Target, Gift, Lock, Shield
} from 'lucide-react';
import {
  ConnectionProvider,
  WalletProvider,
  useWallet,
} from '@solana/wallet-adapter-react';
import { WalletModalProvider, WalletMultiButton } from '@solana/wallet-adapter-react-ui';
import { clusterApiUrl } from '@solana/web3.js';
import {
  PhantomWalletAdapter,
  SolflareWalletAdapter,
} from '@solana/wallet-adapter-wallets';

// Import wallet adapter CSS
import '@solana/wallet-adapter-react-ui/styles.css';

function App() {
  const endpoint = useMemo(() => clusterApiUrl('mainnet-beta'), []);

  const wallets = useMemo(
    () => [
      new PhantomWalletAdapter(),
      new SolflareWalletAdapter(),
    ],
    []
  );

  return (
    <ConnectionProvider endpoint={endpoint}>
      <WalletProvider wallets={wallets} autoConnect>
        <WalletModalProvider>
          <AppContent />
        </WalletModalProvider>
      </WalletProvider>
    </ConnectionProvider>
  );
}

function AppContent() {
  const { connected } = useWallet();
  const [isDarkMode, setIsDarkMode] = useState(true);
  const [price, setPrice] = useState("0.000042");
  const [marketCap, setMarketCap] = useState("$420,690");
  const [isVisible, setIsVisible] = useState(false);
  const [tokenomics, setTokenomics] = useState({
    circulatingSupply: "42,000,000,000",
    burned: "6,900,000,000",
    holders: "4,200",
    reflections: "1,337,000",
    liquidity: "69,420"
  });

  useEffect(() => {
    setIsVisible(true);
    const interval = setInterval(() => {
      // Simulate price movement
      setPrice((prev) => {
        const change = Math.random() > 0.5 ? 0.000001 : -0.000001;
        return (parseFloat(prev) + change).toFixed(6);
      });
      
      // Update market stats
      setTokenomics(prev => ({
        ...prev,
        burned: (parseInt(prev.burned.replace(/,/g, '')) + Math.floor(Math.random() * 1000)).toLocaleString(),
        holders: (parseInt(prev.holders.replace(/,/g, '')) + Math.floor(Math.random() * 10)).toLocaleString(),
        reflections: (parseInt(prev.reflections.replace(/,/g, '')) + Math.floor(Math.random() * 100)).toLocaleString(),
        liquidity: (parseInt(prev.liquidity.replace(/,/g, '')) + Math.floor(Math.random() * 50)).toLocaleString()
      }));
    }, 3000);

    return () => clearInterval(interval);
  }, []);

  const roadmapItems = [
    {
      phase: "Phase 1",
      title: "Launch 🚀",
      items: [
        "Website Launch",
        "Social Media Setup",
        "Community Building",
        "Raydium Listing"
      ],
      completed: true
    },
    {
      phase: "Phase 2",
      title: "Growth 📈",
      items: [
        "1,000+ Holders",
        "Marketing Push",
        "CEX Listings",
        "Meme Contest"
      ],
      completed: false
    },
    {
      phase: "Phase 3",
      title: "Expansion 🌍",
      items: [
        "NFT Collection",
        "Staking Platform",
        "DAO Governance",
        "Major CEX Listings"
      ],
      completed: false
    }
  ];

  return (
    <div className={`min-h-screen transition-colors duration-300 font-['Montserrat'] ${
      isDarkMode 
        ? 'bg-gradient-to-b from-purple-900 via-black to-black text-white' 
        : 'bg-gradient-to-b from-purple-100 via-white to-white text-gray-900'
    }`}>
      {/* Theme Toggle */}
      <div className="fixed top-4 right-4 z-50 flex items-center gap-4">
        <WalletMultiButton className="!bg-gradient-to-r from-purple-500 to-pink-500 !rounded-full" />
        <button
          onClick={() => setIsDarkMode(!isDarkMode)}
          className="p-2 rounded-full bg-opacity-20 backdrop-blur-md hover:bg-opacity-30 transition-all"
          style={{ background: isDarkMode ? 'rgba(255,255,255,0.1)' : 'rgba(0,0,0,0.1)' }}
        >
          {isDarkMode ? <Sun className="w-6 h-6" /> : <Moon className="w-6 h-6" />}
        </button>
      </div>

      {/* Floating Buy Button */}
      <a
        href="https://raydium.io"
        target="_blank"
        rel="noopener noreferrer"
        className="fixed bottom-8 right-8 z-50 bg-gradient-to-r from-purple-500 to-pink-500 px-6 py-3 rounded-full text-white font-bold shadow-lg hover:scale-105 transition-transform flex items-center gap-2"
      >
        <DollarSign className="w-5 h-5" />
        Buy $MRN Now
      </a>

      {/* Hero Section */}
      <header className="relative min-h-screen flex items-center justify-center overflow-hidden">
        <div className={`absolute inset-0 bg-[url('https://images.unsplash.com/photo-1639762681485-074b7f938ba0?auto=format&fit=crop&q=80')] bg-cover bg-center ${
          isDarkMode ? 'opacity-20' : 'opacity-10'
        }`}></div>
        <div className={`relative z-10 container mx-auto px-4 text-center transform transition-all duration-1000 ${
          isVisible ? 'translate-y-0 opacity-100' : 'translate-y-10 opacity-0'
        }`}>
          <img 
            src="data:image/png;base64,YOUR_BASE64_ENCODED_LOGO"
            alt="MRN Logo"
            className="w-48 h-48 mx-auto mb-8 animate-pulse"
          />
          <h1 className="text-7xl font-bold mb-6 bg-gradient-to-r from-purple-400 to-pink-600 text-transparent bg-clip-text">
            $MRN
          </h1>
          <p className={`text-2xl mb-8 ${isDarkMode ? 'text-purple-200' : 'text-purple-800'}`}>
            The Most Revolutionary Nothing You'll Ever Own
          </p>
          
          {/* Enhanced Price Widget */}
          <div className={`inline-block mb-8 p-6 rounded-2xl backdrop-blur-md ${
            isDarkMode ? 'bg-purple-900/30' : 'bg-purple-100/70'
          }`}>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
              <div>
                <p className={`text-sm ${isDarkMode ? 'text-purple-300' : 'text-purple-700'}`}>Current Price</p>
                <div className="flex items-center gap-2 justify-center">
                  <TrendingUp className="w-5 h-5 text-green-400" />
                  <p className="text-2xl font-bold">${price}</p>
                </div>
              </div>
              <div className="border-l border-purple-500/30">
                <p className={`text-sm ${isDarkMode ? 'text-purple-300' : 'text-purple-700'}`}>Market Cap</p>
                <p className="text-2xl font-bold">{marketCap}</p>
              </div>
              <div className="border-l border-purple-500/30">
                <p className={`text-sm ${isDarkMode ? 'text-purple-300' : 'text-purple-700'}`}>Total Supply</p>
                <p className="text-2xl font-bold">{tokenomics.circulatingSupply}</p>
              </div>
              <div className="border-l border-purple-500/30">
                <p className={`text-sm ${isDarkMode ? 'text-purple-300' : 'text-purple-700'}`}>Liquidity</p>
                <p className="text-2xl font-bold">${tokenomics.liquidity}</p>
              </div>
            </div>
            <div className="mt-4 pt-4 border-t border-purple-500/30">
              <div className="flex justify-center gap-4">
                <a
                  href="https://dexscreener.com"
                  target="_blank"
                  rel="noopener noreferrer"
                  className={`px-4 py-2 rounded-lg transition-colors ${
                    isDarkMode 
                      ? 'bg-purple-800/50 hover:bg-purple-700/50' 
                      : 'bg-purple-100 hover:bg-purple-200'
                  }`}
                >
                  DEX Screener
                </a>
                <a
                  href="https://raydium.io/swap"
                  target="_blank"
                  rel="noopener noreferrer"
                  className={`px-4 py-2 rounded-lg transition-colors ${
                    isDarkMode 
                      ? 'bg-purple-800/50 hover:bg-purple-700/50' 
                      : 'bg-purple-100 hover:bg-purple-200'
                  }`}
                >
                  Trade Now
                </a>
              </div>
            </div>
          </div>

          <div className="flex gap-4 justify-center">
            {!connected ? (
              <WalletMultiButton className="!bg-gradient-to-r from-purple-500 to-pink-500 !rounded-full !px-8 !py-4 !text-xl !font-bold hover:!scale-105 transition-transform" />
            ) : (
              <a
                href="https://raydium.io"
                target="_blank"
                rel="noopener noreferrer"
                className="inline-block bg-gradient-to-r from-purple-500 to-pink-500 px-8 py-4 rounded-full text-xl font-bold hover:scale-105 transition-transform text-white"
              >
                Buy Now 🚀
              </a>
            )}
            <a
              href="#about"
              className={`inline-block px-8 py-4 rounded-full text-xl font-bold hover:scale-105 transition-transform border-2 ${
                isDarkMode 
                  ? 'border-purple-500 text-purple-300 hover:bg-purple-500/20' 
                  : 'border-purple-600 text-purple-700 hover:bg-purple-100'
              }`}
            >
              Learn More
            </a>
          </div>
        </div>
      </header>

      {/* Security & Transparency Section */}
      <section className="py-20">
        <div className="container mx-auto px-4">
          <h2 className="text-4xl font-bold text-center mb-16">Security & Transparency</h2>
          <div className="grid md:grid-cols-3 gap-8 max-w-4xl mx-auto">
            <div className={`p-8 rounded-2xl backdrop-blur transition-transform hover:scale-105 ${
              isDarkMode ? 'bg-purple-900/30' : 'bg-white/70'
            }`}>
              <Shield className={`w-12 h-12 mb-4 ${isDarkMode ? 'text-purple-400' : 'text-purple-600'}`} />
              <h3 className="text-2xl font-bold mb-4">Liquidity Locked</h3>
              <p>100% of liquidity tokens are locked for 1 year, ensuring price stability and security.</p>
            </div>
            <div className={`p-8 rounded-2xl backdrop-blur transition-transform hover:scale-105 ${
              isDarkMode ? 'bg-purple-900/30' : 'bg-white/70'
            }`}>
              <Lock className={`w-12 h-12 mb-4 ${isDarkMode ? 'text-purple-400' : 'text-purple-600'}`} />
              <h3 className="text-2xl font-bold mb-4">Contract Renounced</h3>
              <p>Contract ownership has been renounced, making $MRN truly community-owned.</p>
            </div>
            <div className={`p-8 rounded-2xl backdrop-blur transition-transform hover:scale-105 ${
              isDarkMode ? 'bg-purple-900/30' : 'bg-white/70'
            }`}>
              <Target className={`w-12 h-12 mb-4 ${isDarkMode ? 'text-purple-400' : 'text-purple-600'}`} />
              <h3 className="text-2xl font-bold mb-4">Fair Launch</h3>
              <p>No pre-sale, no team tokens. Everyone gets the same fair chance to buy.</p>
            </div>
          </div>
        </div>
      </section>

      {/* Tokenomics Dashboard */}
      <section className={`py-20 ${isDarkMode ? 'bg-black/50' : 'bg-purple-50'}`}>
        <div className="container mx-auto px-4">
          <h2 className="text-4xl font-bold text-center mb-16">Tokenomics</h2>
          <div className="grid md:grid-cols-4 gap-8">
            <div className={`p-8 rounded-2xl backdrop-blur transition-transform hover:scale-105 ${
              isDarkMode ? 'bg-purple-900/30' : 'bg-white/70'
            }`}>
              <ChartPie className={`w-12 h-12 mb-4 ${isDarkMode ? 'text-purple-400' : 'text-purple-600'}`} />
              <h3 className="text-xl font-bold mb-2">Circulating Supply</h3>
              <p className="text-2xl font-bold">{tokenomics.circulatingSupply}</p>
            </div>
            <div className={`p-8 rounded-2xl backdrop-blur transition-transform hover:scale-105 ${
              isDarkMode ? 'bg-purple-900/30' : 'bg-white/70'
            }`}>
              <Flame className={`w-12 h-12 mb-4 ${isDarkMode ? 'text-purple-400' : 'text-purple-600'}`} />
              <h3 className="text-xl font-bold mb-2">Total Burned</h3>
              <p className="text-2xl font-bold">{tokenomics.burned}</p>
            </div>
            <div className={`p-8 rounded-2xl backdrop-blur transition-transform hover:scale-105 ${
              isDarkMode ? 'bg-purple-900/30' : 'bg-white/70'
            }`}>
              <Users className={`w-12 h-12 mb-4 ${isDarkMode ? 'text-purple-400' : 'text-purple-600'}`} />
              <h3 className="text-xl font-bold mb-2">Holders</h3>
              <p className="text-2xl font-bold">{tokenomics.holders}</p>
            </div>
            <div className={`p-8 rounded-2xl backdrop-blur transition-transform hover:scale-105 ${
              isDarkMode ? 'bg-purple-900/30' : 'bg-white/70'
            }`}>
              <Gift className={`w-12 h-12 mb-4 ${isDarkMode ? 'text-purple-400' : 'text-purple-600'}`} />
              <h3 className="text-xl font-bold mb-2">Reflections</h3>
              <p className="text-2xl font-bold">{tokenomics.reflections}</p>
            </div>
          </div>
        </div>
      </section>

      {/* What is $MRN Section */}
      <section id="about" className="py-20">
        <div className="container mx-auto px-4">
          <h2 className="text-4xl font-bold text-center mb-16">What is $MRN?</h2>
          <div className="grid md:grid-cols-3 gap-8">
            <div className={`p-8 rounded-2xl backdrop-blur transition-transform hover:scale-105 ${
              isDarkMode ? 'bg-purple-900/30' : 'bg-white/70'
            }`}>
              <Coins className={`w-12 h-12 mb-4 ${isDarkMode ? 'text-purple-400' : 'text-purple-600'}`} />
              <h3 className="text-2xl font-bold mb-4">Pure Meme Magic</h3>
              <p>No utility. No purpose. Just vibes and guaranteed fun on the journey to the moon! 🌙</p>
            </div>
            <div className={`p-8 rounded-2xl backdrop-blur transition-transform hover:scale-105 ${
              isDarkMode ? 'bg-purple-900/30' : 'bg-white/70'
            }`}>
              <Zap className={`w-12 h-12 mb-4 ${isDarkMode ? 'text-purple-400' : 'text-purple-600'}`} />
              <h3 className="text-2xl font-bold mb-4">Solana Powered</h3>
              <p>Lightning-fast transactions and minimal fees on Solana's powerful blockchain.</p>
            </div>
            <div className={`p-8 rounded-2xl backdrop-blur transition-transform hover:scale-105 ${
              isDarkMode ? 'bg-purple-900/30' : 'bg-white/70'
            }`}>
              <Users className={`w-12 h-12 mb-4 ${isDarkMode ? 'text-purple-400' : 'text-purple-600'}`} />
              <h3 className="text-2xl font-bold mb-4">Strong Community</h3>
              <p>Join thousands of diamond-handed degens on our journey to financial memes!</p>
            </div>
          </div>
        </div>
      </section>

      {/* Roadmap Section */}
      <section className={`py-20 ${isDarkMode ? 'bg-black/50' : 'bg-purple-50'}`}>
        <div className="container mx-auto px-4">
          <h2 className="text-4xl font-bold text-center mb-16">Roadmap</h2>
          <div className="max-w-4xl mx-auto">
            {roadmapItems.map((item, index) => (
              <div key={item.phase} className="relative pb-12 last:pb-0">
                {index !== roadmapItems.length - 1 && (
                  <div className="absolute left-8 top-8 bottom-0 w-0.5 bg-purple-500/30"></div>
                )}
                <div className="flex gap-8">
                  <div className={`w-16 h-16 rounded-full flex items-center justify-center flex-shrink-0 ${
                    item.completed
                      ? 'bg-gradient-to-r from-purple-500 to-pink-500'
                      : isDarkMode ? 'bg-purple-900/30' : 'bg-white/70'
                  }`}>
                    <Target className="w-8 h-8" />
                  </div>
                  <div className={`p-6 rounded-2xl backdrop-blur flex-grow ${
                    isDarkMode ? 'bg-purple-900/30' : 'bg-white/70'
                  }`}>
                    <h3 className="text-2xl font-bold mb-2">{item.phase}: {item.title}</h3>
                    <ul className="space-y-2">
                      {item.items.map((listItem, i) => (
                        <li key={i} className="flex items-center gap-2">
                          {item.completed ? '✅' : '⭐'} {listItem}
                        </li>
                      ))}
                    </ul>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* How to Buy Section */}
      <section className="py-20">
        <div className="container mx-auto px-4">
          <h2 className="text-4xl font-bold text-center mb-16">How to Buy $MRN</h2>
          <div className="max-w-3xl mx-auto">
            <div className="space-y-8">
              <div className="flex items-start gap-4">
                <div className="bg-purple-500 p-4 rounded-full">
                  <ShoppingCart className="w-8 h-8 text-white" />
                </div>
                <div>
                  <h3 className="text-2xl font-bold mb-2">1. Get SOL</h3>
                  <p className={isDarkMode ? 'text-purple-200' : 'text-purple-800'}>
                    Purchase SOL from your favorite exchange and send it to your Phantom wallet.
                  </p>
                </div>
              </div>
              <div className="flex items-start gap-4">
                <div className="bg-purple-500 p-4 rounded-full">
                  <Timer className="w-8 h-8 text-white" />
                </div>
                <div>
                  <h3 className="text-2xl font-bold mb-2">2. Visit Raydium</h3>
                  <p className={isDarkMode ? 'text-purple-200' : 'text-purple-800'}>
                    Connect your wallet to Raydium and swap your SOL for $MRN.
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* NFT/Utility Section */}
      <section className={`py-20 ${isDarkMode ? 'bg-black/50' : 'bg-purple-50'}`}>
        <div className="container mx-auto px-4">
          <h2 className="text-4xl font-bold text-center mb-16">Upcoming Utilities</h2>
          <div className="grid md:grid-cols-2 gap-8 max-w-4xl mx-auto">
            <div className={`p-8 rounded-2xl backdrop-blur transition-transform hover:scale-105 ${
              isDarkMode ? 'bg-purple-900/30' : 'bg-white/70'
            }`}>
              <Gift className={`w-12 h-12 mb-4 ${isDarkMode ? 'text-purple-400' : 'text-purple-600'}`} />
              <h3 className="text-2xl font-bold mb-4">NFT Collection</h3>
              <p>Exclusive NFT collection coming soon with unique utilities and rewards for holders! 🎨</p>
            </div>
            <div className={`p-8 rounded-2xl backdrop-blur transition-transform hover:scale-105 ${
              isDarkMode ? 'bg-purple-900/30' : 'bg-white/70'
            }`}>
              <Lock className={`w-12 h-12 mb-4 ${isDarkMode ? 'text-purple-400' : 'text-purple-600'}`} />
              <h3 className="text-2xl font-bold mb-4">Staking Platform</h3>
              <p>Earn passive rewards by staking your $MRN tokens in our upcoming staking platform! 💎</p>
            </div>
          </div>
        </div>
      </section>

      {/* Community Links */}
      <footer className={`py-20 ${isDarkMode ? 'bg-black/50' : 'bg-purple-50'}`}>
        <div className="container mx-auto px-4 text-center">
          <h2 className="text-4xl font-bold mb-12">Join the $MRN Community</h2>
          <div className="flex justify-center gap-8">
            <a
              href="https://t.me/mrntoken"
              target="_blank"
              rel="noopener noreferrer"
              className={`p-6 rounded-2xl transition-colors ${
                isDarkMode 
                  ? 'bg-purple-900/30 hover:bg-purple-800/30' 
                  : 'bg-white/70 hover:bg-purple-100/70'
              }`}
            >
              Telegram
            </a>
            <a
              href="https://twitter.com/mrntoken"
              target="_blank"
              rel="noopener noreferrer"
              className={`p-6 rounded-2xl transition-colors ${
                isDarkMode 
                  ? 'bg-purple-900/30 hover:bg-purple-800/30' 
                  : 'bg-white/70 hover:bg-purple-100/70'
              }`}
            >
              Twitter
            </a>
            <a
              href="https://raydium.io"
              target="_blank"
              rel="noopener noreferrer"
              className={`p-6 rounded-2xl transition-colors ${
                isDarkMode 
                  ? 'bg-purple-900/30 hover:bg-purple-800/30' 
                  : 'bg-white/70 hover:bg-purple-100/70'
              }`}
            >
              Raydium
            </a>
          </div>
        </div>
      </footer>
    </div>
  );
}

export default App;